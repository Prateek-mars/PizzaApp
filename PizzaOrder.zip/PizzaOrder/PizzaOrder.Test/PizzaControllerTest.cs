using Microsoft.AspNetCore.Mvc;
using PizzaOrder.Api.Controllers;
using PizzaOrder.Api.Repository.Abstract;
using System;
using Xunit;

namespace PizzaOrder.Test
{
    public class PizzaControllerTest
    {
        PizzaController _controller;
        private readonly IPizzaTypeRepository _pizzaTypeRepository;
        private readonly ISizeRepository _sizeRepository;
        private readonly IToppingRepository _toppingRepository;
        public PizzaControllerTest()
        {
            _controller = new PizzaController(_pizzaTypeRepository, _sizeRepository, _toppingRepository);
        }


        [Fact]
        public void GetPizzaTypes_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetPizzaTypes();

            // Assert
            Assert.IsType<OkObjectResult>(okResult);
        }       
    }
}
