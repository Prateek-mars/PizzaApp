﻿using Microsoft.AspNetCore.Mvc;
using PizzaOrder.Api.Controllers;
using PizzaOrder.Api.Helpers;
using PizzaOrder.Api.Models;
using PizzaOrder.Api.Repository.Abstract;
using PizzaOrder.Api.Services.Abstract;
using System;
using System.Collections.Generic;
using Xunit;

namespace PizzaOrder.Test
{

    public class CartControllerTest
    {
        CartController _controller;
        private ICartSessionService _cartSessionService;
        private ICartService _cartService;
        private IPizzaPriceCalculater _pizzaPriceCalculater;
        private IPizzaTypeRepository _pizzaTypeRepository;
        private ISizeRepository _sizeRepository;

        public CartControllerTest()
        {
            _controller = new CartController(_cartSessionService, _cartService, _pizzaPriceCalculater, _pizzaTypeRepository, _sizeRepository);
        }

        [Fact]
        public void GetTotalQuantity_WhenCalled_ReturnsOkResult()
        {
            // Act

            var cart = _cartSessionService.GetCart();

            PizzaToAddCart pizzaToAddCart = new PizzaToAddCart
            {
                Id = 1,
                PizzaName = "",
                NumberOfPizza = 2,
                Price = 25,
                Toppings = new List<string>()
            };

            _cartService.AddTocart(cart, pizzaToAddCart);

            _cartSessionService.SetCart(cart);

            var cart2 = _cartSessionService.GetCart();          

            // Assert
            Assert.IsType<OkObjectResult>(pizzaToAddCart);
        }
    }
}
