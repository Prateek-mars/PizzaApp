﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaOrder.Api.Models
{
    public class CartToGetDto
    {
        public int MyProperty { get; set; }
    }
}
