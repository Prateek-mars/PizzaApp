﻿using PizzaOrder.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaOrder.Api.Services.Abstract
{
   public interface IPizzaPriceCalculater
    {
        decimal Calculate(decimal size, decimal pizzaType, int edgeTypeId, int number);
    }
}
