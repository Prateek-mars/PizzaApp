﻿using PizzaOrder.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaOrder.Api.Repository.Abstract
{
    public interface IPizzaTypeRepository
    {
        List<PizzaType> GetAllPizzas();

        decimal GetPizzaTypePrice(int pizzaTypeId);

        string GetPizzaTypeName(int pizzaTypeId);
    }
}
