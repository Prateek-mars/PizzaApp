export class SizeForOrder {
    id: number;
    name: string;
    multiplier: number;
}
