export class Pizza {
    id: number;
    pizzaName: string;
    toppings: string[];
    price: number;
    numberOfPizza: number;
}
