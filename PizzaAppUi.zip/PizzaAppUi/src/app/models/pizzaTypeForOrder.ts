export class PizzaTypeForOrder {
    id: number;
    name: string;
    price: number;
}
