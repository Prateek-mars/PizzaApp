import { Pizza } from './pizza';

export class CartLine {
    pizza: Pizza;
    quantity: number;
}
