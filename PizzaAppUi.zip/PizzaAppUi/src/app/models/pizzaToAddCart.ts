export class PizzaToAddCart {
    pizzaTypeId: number;
    sizeId: number;
    toppings: string[];
    edgeTypeId: number;
    number: number;
}