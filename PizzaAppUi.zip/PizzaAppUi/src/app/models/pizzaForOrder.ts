export class PizzaForOrder {
    id: number;
    sizeId: number;
    pizzaToppings: string[];
    pizzaTypeId: number;

}
