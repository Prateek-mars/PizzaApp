export class HttpRouteGetter {
   httpRoute = 'https://localhost:44375/api/';
}

